#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "motor.h"
#include "run.h"
#include "bluetooth.h"
#include "linewalking.h"
#include "bsp_linewalking.h"
#include "hc_sr04.h"
#include "timer.h"
#include "servo.h"
#include "colorful.h"

////����ȫ�ʵƹ���
//void testColorful()
//{
//	Colorful_Control(1, 0, 0);
//	delay_ms(500);
//	Colorful_Control(0, 1, 0);
//	delay_ms(500);
//	Colorful_Control(0, 0, 1);
//	delay_ms(500);
//	Colorful_Control(1, 1, 0);
//	delay_ms(500);
//	Colorful_Control(1, 0, 1);
//	delay_ms(500);
//	Colorful_Control(0, 1, 1);
//	delay_ms(500);
//	Colorful_Control(1, 1, 1);
//	delay_ms(500);
//	Colorful_Control(0, 0, 0);
//	delay_ms(500);
//}

int main(void)
{
	delay_init();
	Uart2_init(9600);
	MOTOR_GPIO_Init();
	Motor_PWM_Init(7200,0,7200,0);
	LineWalking_GPIO_Init();
	Colorful_GPIO_Init();
	Ultrasonic_GPIO_Init();
	Buzzer_GPIO_Init();
	Buzzer_Control(OFF);
  TIM3_Int_Init(999,71);
	TIM1_Int_Init(9,71);
	Servo_GPIO_Init();
	TIM_Cmd(TIM1, ENABLE);
	Angle_J1=90;
	delay_ms(1000);
	TIM_Cmd(TIM1, DISABLE);
	while(1)
	{
		//testColorful();
		app_LineWalking();
	}
}
