/**
* @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
* @file         app_linewalking.c	
* @author       liusen
* @version      V1.0
* @date         2017.07.17
* @brief        Ѳ��ģʽ�˶�
* @details      
* @par History  ������˵��
*                 
* version:		liusen_20170717
*/

#include "linewalking.h"
#include "bsp_linewalking.h"
#include "sys.h"
#include "motor.h"
#include "run.h"
#include "delay.h"
#include "hc_sr04.h"
#include "servo.h"
#include "timer.h"
#include "colorful.h"
#include "buzzer.h"
int Area=0;
int LastArea=0;
static float speed_time=1.2;
/**
* Function       app_LineWalking
* @author        liusen
* @date          2017.07.20    
* @brief         Ѳ��ģʽ�˶�
* @param[in]     void
* @param[out]    void
* @retval        void
* @par History   ��
*/

void app_LineWalking(void)
{
    int LineL1 = 1, LineL2 = 1, LineR1 = 1, LineR2 = 1;

    bsp_GetLineWalking(&LineL1, &LineL2, &LineR1, &LineR2);

		if(LineL1&&!LineL2&&!LineR1&&LineR2)//ֱ��
		{
			Area=3;
			Colorful_Control(0,1,0);//green
			Car_Run(2000/speed_time);	
		}
		else if(!LineL1&&!LineL2&&!LineR1&&!LineR2)
		{
				TIM_Cmd(TIM1, ENABLE);
				Car_Stop();
				delay_ms(1000);
				int i=0;
			
        int flag_right=0;int flag_on=0;int flag_left=0;
			  int length=0;
			
				for(i=0;i<180;i++)
				{
					if(i>=0&&i<5){
						length=GetLength();
						if(length>0&&length<25){ flag_right=1;Colorful_Control(1,0,0);Buzzer_Control(ON);}
					}
					if(i>=88&&i<=92){  
						length=GetLength();
						if(length>0&&length<25) {flag_on=1;Colorful_Control(1,0,0);Buzzer_Control(ON);}
					}
					if(i>=177&&i<=179){
						length=GetLength();
						if(length>0&&length<25) {flag_left=1;Colorful_Control(1,0,0);Buzzer_Control(ON);}
					}
					Angle_J1=i;
					delay_ms(20);
					
				}

				
				for(i=180;i>89;i--)
				{
					Colorful_Control(0,1,0);//green
					Angle_J1=i;
					delay_ms(20);
				}

				Buzzer_Control(OFF);
				
				if(!flag_right){
					Area=7;
			    Car_SpinRight(3200/speed_time,3200/speed_time);
					delay_ms(200);
				}

				if(!flag_on&&flag_right){
					Area=3;
					Car_Run(2000/speed_time);
					delay_ms(200);					
				}
				
				if(!flag_left&&flag_on&&flag_right){
					Area=8;
          Car_SpinLeft(3200/speed_time,3200/speed_time);
					delay_ms(200);
				}
				TIM_Cmd(TIM1, DISABLE);
		}
		else if(LineL1&&LineL2&&!LineR1&&LineR2)//��С��
		{
			Area=4;
			Car_Right(2000/speed_time);
		}
		else if(LineL1&&LineL2&&LineR1&&!LineR2)//�Ҵ���
		{
			Area=6;
			Car_SpinRight(3200/speed_time,3200/speed_time);
		}		
		else if(LineL1&&!LineL2&&LineR1&&LineR2)//��С��
		{
			Area=2;
			Car_Left(2000/speed_time);
		}
		else if(!LineL1&&LineL2&&LineR1&&LineR2)//�����
		{
			Area=0;
			Car_SpinLeft(3200/speed_time,3200/speed_time);
		}		
		else if(LineL1&&LineL2&&LineR1&&LineR2)//��������
		{
			if(LastArea==4)//Area5,������
			{
				Area=5;
				Car_SpinRight(2400/speed_time,2400/speed_time);
			}
			else if(LastArea==2)//Area1,������
			{
				Area=1;
				Car_SpinLeft(2400/speed_time,2400/speed_time);
			}
		}
		else if(LineL1&&!LineL2&&!LineR1&&!LineR2)//��ֱ��
		{
			Area=7;
			delay_ms(10);
			Colorful_Control(0,0,1);
			Car_SpinRight(3200/speed_time,3200/speed_time);
			Buzzer_Control(ON);
			delay_ms(100);
			Buzzer_Control(OFF);
		}	
		else if(!LineL1&&!LineL2&&!LineR1&&LineR2)//��ֱ��
		{
			Area=8;
			delay_ms(10);
			Colorful_Control(0,0,1);		
			Car_SpinLeft(3200/speed_time,3200/speed_time);
			Buzzer_Control(ON);
			delay_ms(100);
			Buzzer_Control(OFF);
		}
		else if(LineL1&&LineL2&&LineR1&&LineR2)
		{
			LastArea=9;
			if(LastArea==7)
			{ 
				Car_SpinRight(3200/speed_time,3200/speed_time);
				delay_ms(100);
			}
			else if(LastArea==8)
			{
				Car_SpinLeft(3200/speed_time,3200/speed_time);
				delay_ms(100);
			}
			else if(LastArea==3)
			{
				Car_SpinRight(3200/speed_time,3200/speed_time);
			}
			else if(LastArea==9)
			{
				Car_Stop();
				delay_ms(1000);
			}
			
		}

		
}
