#include "stm32f10x.h"
#ifndef _HC_SR04_H
#define _HC_SR04_H

void Ultrasonic_GPIO_Init(void);
void TIM3_Int_Init(u16 arr,u16 psc);
void Open_Tim3(void);
void Close_Tim3(void);
float GetLength (void);
float bsp_getUltrasonicDistance(void);
#define TRIG_Send(a)   if(a)\
											 GPIO_SetBits(GPIOA,GPIO_Pin_15);\
											 else\
											 GPIO_ResetBits(GPIOA,GPIO_Pin_15)
        
				
#define ECHO_Reci GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)				
  

#endif



