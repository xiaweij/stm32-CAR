#include "stm32f10x.h"

#ifndef _COLORFUL_H
#define _COLORFUL_H



void Colorful_GPIO_Init(void);

void Colorful_Control(int v_RedOnOff, int v_GreenOnOff, int v_BlueOnOff);
#endif
