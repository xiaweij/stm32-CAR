/**
* @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
* @file         app_linewalking.h
* @author       liusen
* @version      V1.0
* @date         2017.07.20
* @brief        Ѳ��ģʽͷ�ļ�
* @details      
* @par History  ������˵��
*                 
* version:	liusen_20170717
*/

#ifndef __LINEWALKING_H__
#define __LINEWALKING_H__	


void app_LineWalking(void);


#endif



